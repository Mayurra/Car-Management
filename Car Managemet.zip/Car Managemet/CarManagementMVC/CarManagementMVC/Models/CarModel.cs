﻿using System.ComponentModel.DataAnnotations;

namespace CarManagementMVC.Models
{
    public class CarModel
    {
        [Key]
        public int? Id { get; set; }

        [Required]
        public string? Brand { get; set; }

        [Required]
        public string? Class { get; set; }

        [Required]
        public string? ModelName { get; set; }

        [Required, MaxLength(10), RegularExpression(@"^[a-zA-Z0-9]*$")]
        public string? ModelCode { get; set; }

        [Required]
        public string? Description { get; set; }

        [Required]
        public string? Features { get; set; }

        [Required]
        public decimal Price { get; set; }

        [Required]
        public DateTime DateOfManufacturing { get; set; }

        public bool Active { get; set; }

        public int SortOrder { get; set; }

        public string? Images { get; set; }

    }
}
