﻿namespace CarManagementMVC.Models
{
    public class CarService
    {
        private readonly HttpClient _httpClient;

        public CarService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<CarModel>> GetCarAsync()
        {
            return await _httpClient.GetFromJsonAsync<List<CarModel>>("api/Car");
            
        }

        public async Task<CarModel> GetCarAsync(int id)
        {
            return await _httpClient.GetFromJsonAsync<CarModel>($"api/Car/{id}");
        }

        public async Task<CarModel> CreateCarAsync(CarModel loCars)
        {
            var response = await _httpClient.PostAsJsonAsync("api/Car", loCars);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<CarModel>();
        }

        public async Task UpdateCarAsync(CarModel loCars)
        {
            var response = await _httpClient.PutAsJsonAsync($"api/Car/{loCars.Id}", loCars);
            response.EnsureSuccessStatusCode();
        }

        public async Task DeleteCarAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"api/Car/{id}");
            response.EnsureSuccessStatusCode();
        }
    }
}
