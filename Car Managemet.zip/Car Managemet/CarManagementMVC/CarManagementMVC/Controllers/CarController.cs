﻿using CarManagementMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace CarManagementMVC.Controllers
{
    public class CarController : Controller
    {
        private readonly CarService _carService;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public CarController(CarService carService, IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
            _carService = carService;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var cars = await _carService.GetCarAsync();
            return View("~/Views/Cars/CarList.cshtml", cars);
        }

        public IActionResult Create() => View("~/Views/Cars/AddCar.cshtml");

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CarModel loCars, IFormFile ImageFile)
        {
            if (ModelState.IsValid) 
            {
                if(loCars.Id == null)
                    loCars.Id = 0;

                if (ImageFile != null && ImageFile.Length > 0)
                {
                    // Generate a unique filename
                    var fileName = Path.GetFileNameWithoutExtension(ImageFile.FileName);
                    var extension = Path.GetExtension(ImageFile.FileName);
                    var uniqueFileName = $"{fileName}_{Guid.NewGuid()}{extension}";

                    // Save the file to the wwwroot/images/cars folder
                    var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images/cars");
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        ImageFile.CopyTo(fileStream);
                    }

                    loCars.Images = Path.Combine("images/cars", uniqueFileName);
                }

                await _carService.CreateCarAsync(loCars);
                return RedirectToAction(nameof(Index));
            }
            return View("~/Views/Cars/AddCar.cshtml", loCars);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var car = await _carService.GetCarAsync(id);
            if (car == null) return NotFound();
            return View("~/Views/Cars/EditCar.cshtml", car);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, CarModel loCars, IFormFile ImageFile)
        {
            if (id != loCars.Id) return NotFound();

            if (ModelState.IsValid)
            {
                if (ImageFile != null && ImageFile.Length > 0)
                {
                    // Generate a unique filename
                    var fileName = Path.GetFileNameWithoutExtension(ImageFile.FileName);
                    var extension = Path.GetExtension(ImageFile.FileName);
                    var uniqueFileName = $"{fileName}_{Guid.NewGuid()}{extension}";

                    // Save the file to the wwwroot/images/cars folder
                    var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images/cars");
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        ImageFile.CopyTo(fileStream);
                    }

                    loCars.Images = Path.Combine("images/cars", uniqueFileName);
                }

                await _carService.UpdateCarAsync(loCars);
                return RedirectToAction(nameof(Index));
            }
            return View("~/Views/Cars/EditCar.cshtml", loCars);
        }

        public async Task<IActionResult> Delete(int id)
        {
            await _carService.DeleteCarAsync(id);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> SearchCars(string txtSearch)
        {
            // Logic to search for cars based on the modelName and modelCode
            var cars = await _carService.GetCarAsync(); // Replace with your actual data fetching logic

            var filteredCars = cars.Where(c => c.ModelName == txtSearch || c.ModelCode == txtSearch).ToList();

            if (!filteredCars.Any())
            {
                return NotFound("No cars found matching the search criteria.");
            }

            return View("~/Views/Cars/CarList.cshtml", filteredCars);
        }
    }
}
