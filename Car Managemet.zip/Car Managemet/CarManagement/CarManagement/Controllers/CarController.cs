﻿using CarManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CarManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarController : ControllerBase
    {
        private readonly CarContext _dbContext;

        public CarController(CarContext dbContext)
        {
            _dbContext = dbContext;
        }

        // GET: api/cars
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CarModel>>> GetCars()
        {
            if (_dbContext.Cars == null)
            {
                return NotFound();
            }
            return await _dbContext.Cars.OrderByDescending(x => x.DateOfManufacturing).ToListAsync();
        }

        // GET: api/cars/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CarModel>> GetCar(int id)
        {
            if (_dbContext.Cars == null)
            {
                return NotFound();
            }
            var car = await _dbContext.Cars.FindAsync(id);
            if (car == null)
            {
                return NotFound();
            }
            return car;
        }

        // POST: api/cars
        [HttpPost]
        public async Task<ActionResult<CarModel>> CreateCar(CarModel carModel)
        {
            _dbContext.Cars.Add(carModel);
            await _dbContext.SaveChangesAsync();
            return CreatedAtAction(nameof(GetCar), new { id = carModel.Id }, carModel);
        }

        // PUT: api/cars/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCar(int id, CarModel carModel)
        {   
            if (id != carModel.Id)
            {
                return BadRequest();
            }
            _dbContext.Entry(carModel).State = EntityState.Modified;

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CarAvailable(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Ok();
        }

        private bool CarAvailable(int id)
        {
            return (_dbContext.Cars?.Any(c => c.Id == id)).GetValueOrDefault();
        }

        // DELETE: api/cars/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCar(int id)
        {
            if (_dbContext.Cars == null)
            {
                return NotFound();
            }

            var car = await _dbContext.Cars.FindAsync(id);
            if (car == null)
            {
                return NotFound();
            }

            _dbContext.Cars.Remove(car);
            await _dbContext.SaveChangesAsync();
            return Ok();
        }
    }
}
